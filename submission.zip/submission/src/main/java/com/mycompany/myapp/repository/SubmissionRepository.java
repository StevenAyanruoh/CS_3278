package com.mycompany.myapp.repository;

import com.mycompany.myapp.domain.Submission;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Submission entity.
 */
@SuppressWarnings("unused")
public interface SubmissionRepository extends JpaRepository<Submission,Long> {

}
