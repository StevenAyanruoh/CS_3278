(function() {
    'use strict';

    angular
        .module('csx278MidtermApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
