(function() {
    'use strict';

    angular
        .module('csx278MidtermApp')
        .controller('HomeworkDetailController', HomeworkDetailController);

    HomeworkDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Homework'];

    function HomeworkDetailController($scope, $rootScope, $stateParams, previousState, entity, Homework) {
        var vm = this;

        vm.homework = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('csx278MidtermApp:homeworkUpdate', function(event, result) {
            vm.homework = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
